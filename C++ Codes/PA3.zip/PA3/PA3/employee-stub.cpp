#include "employee.h"

int main()
{
	Employee obj;
	cin >> obj;
	cout << obj;
	return 1;
}